package com.OptimumPool.OfferRide;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfferRideApplicationTests {

	@Test
	void contextLoads() {
	}

}
