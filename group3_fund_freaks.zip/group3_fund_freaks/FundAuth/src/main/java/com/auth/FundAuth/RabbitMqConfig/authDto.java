package com.auth.FundAuth.RabbitMqConfig;

import org.json.simple.JSONObject;

public class authDto {
    private JSONObject jsonObject;

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public authDto() {
        this.jsonObject = jsonObject;
    }
}