package com.auth.FundAuth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FundAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
