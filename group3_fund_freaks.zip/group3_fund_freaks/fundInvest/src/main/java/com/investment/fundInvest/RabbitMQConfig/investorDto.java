package com.investment.fundInvest.RabbitMQConfig;

import org.json.simple.JSONObject;

public class investorDto {
    private JSONObject jsonObject;

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public investorDto() {
        this.jsonObject = jsonObject;
    }
}
