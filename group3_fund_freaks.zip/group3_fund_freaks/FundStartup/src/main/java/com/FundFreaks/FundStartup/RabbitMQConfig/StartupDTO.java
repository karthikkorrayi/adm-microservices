package com.FundFreaks.FundStartup.RabbitMQConfig;

import org.json.simple.JSONObject;

public class StartupDTO {
    private JSONObject jsonObject;

    public JSONObject getJsonObject() {
        return jsonObject;
    }

    public void setJsonObject(JSONObject jsonObject) {
        this.jsonObject = jsonObject;
    }

    public StartupDTO() {
        this.jsonObject = jsonObject;
    }
}
